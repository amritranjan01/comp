#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_IDENTIFIERS 100
#define MAX_KEYWORDS 32

int isKeyword(const char *word);
void displayIdentifiersAndKeywords(const char *filename);

int main() {
    const char *filename = "example.txt";
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Write some content to the file
    fprintf(file, "int main() {\n");
    fprintf(file, "    int count = 0;\n");
    fprintf(file, "    float average = 0.0;\n");
    fprintf(file, "    printf(\"Hello, world!\\n\");\n");
    fprintf(file, "    return 0;\n");
    fprintf(file, "}\n");

    fclose(file);

    // Display identifiers and keywords from the file
    displayIdentifiersAndKeywords(filename);

    return 0;
}

int isKeyword(const char *word) {
    const char *keywords[] = {
        "auto", "break", "case", "char", "const", "continue", "default", "do",
        "double", "else", "enum", "extern", "float", "for", "goto", "if",
        "int", "long", "register", "return", "short", "signed", "sizeof", "static",
        "struct", "switch", "typedef", "union", "unsigned", "void", "volatile", "while"
    };

    int i;
    int numKeywords = sizeof(keywords) / sizeof(keywords[0]);

    for (i = 0; i < numKeywords; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }

    return 0;
}

void displayIdentifiersAndKeywords(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }

    char word[100];
    char identifiers[MAX_IDENTIFIERS][100];
    char keywords[MAX_KEYWORDS][100];
    int identifierCount = 0;
    int keywordCount = 0;

    while (fscanf(file, "%s", word) != EOF) {
        // Remove any special characters or punctuation
        int len = strlen(word);
        if (ispunct(word[len - 1])) {
            word[len - 1] = '\0';
        }

        if (isalpha(word[0])) {
            if (isKeyword(word)) {
                strcpy(keywords[keywordCount++], word);
            } else {
                strcpy(identifiers[identifierCount++], word);
            }
        }
    }

    printf("Identifiers:\n");
    for (int i = 0; i < identifierCount; i++) {
        printf("%s\n", identifiers[i]);
    }

    printf("\nKeywords:\n");
    for (int i = 0; i < keywordCount; i++) {
        printf("%s\n", keywords[i]);
    }

    fclose(file);
}

