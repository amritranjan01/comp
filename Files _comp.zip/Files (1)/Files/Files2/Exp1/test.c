#include <stdio.h>

#define MAX_LINE_LEN 1024

int main() {
  char address[MAX_LINE_LEN];
  char file_name[MAX_LINE_LEN];
  
  FILE *fp;
  printf("Your address: ");
  gets(address);

  printf("Enter the file name to append to: ");
  gets(file_name);
  
 
  fp = fopen(file_name, "a+");
  
  
  if (fp == NULL) return -1;

  fprintf(fp, "Your address: %s\n", address);
  
  fclose(fp);
  
  printf("Your address is appended to the file %s. Open and check.\n", file_name);
  return 0;
}
