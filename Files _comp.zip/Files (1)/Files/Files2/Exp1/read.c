# include <stdio.h>
# include<stdlib.h>
# include <string.h>
 

int main(){
// opening the file
FILE *ptr;
char ch;
ptr=fopen("file.txt","r");
if(ptr==NULL){
printf("file can't be opened\n");
}
printf("contents of file is \n");
// displaying it
do{
ch=fgetc(ptr);
printf("%c",ch);
}while(ch!=EOF);

// closing the file
fclose(ptr);
return 0;
}

