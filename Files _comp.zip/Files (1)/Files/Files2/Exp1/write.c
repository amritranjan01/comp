# include <stdio.h>
# include <stdlib.h>

int main(){
int num;
FILE *ptr;
// opening the file
ptr=fopen("write.txt","w");
if(ptr==NULL){
printf("file is not opened \n");
exit(1);
}
// writing in the file

printf("enter the number \n");
scanf("%d",&num);
// printing in the file

fprintf(ptr,"%d",num);
fclose(ptr);
return 0;
}
