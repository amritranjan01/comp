#include<stdio.h>
#include<stdlib.h> 
char s; 
void e(),eprime(); 
void match(char c){ 
 if(s == c) 
 s = getchar(); 
 else{ 
 printf("Invalid Input detected 1st\n"); 
 exit(0); 
 } 
} 
void eprime(){ 
 if(s == 'a' || s == 'b'){ 
 match(s); 
 eprime(); 
 } 
 else if(s=='$') 
 return; 
 else{ 
 e(); 
 eprime(); 
 } 
} 
void e(){ 
 if(s=='a' || s=='b'){ 
 match(s); 
 eprime(); 
 } 
 else if(s=='$') 
 return; 
 else { 
 printf("Invalid Input detected 2nd\n"); 
 exit(0); 
 } 
 
} 
void main(){ 
 char input[10]; 
 printf("enter the string with the $ at the end\n"); 
 s = getchar(); 
 e(); 
 if(s=='$') 
 printf("parser successfully parsed\n"); 
 else 
 printf("Invalid Input detected 3rd\n"); 
} 