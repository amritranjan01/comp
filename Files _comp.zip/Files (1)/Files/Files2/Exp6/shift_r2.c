# include <stdio.h>
# include <stdlib.h>
# include <string.h>
int z=0,i=0,j=0,c=0;
char a[16],ac[20],stk[15],act[10];
void check(){
    strcpy(ac,"Reduce to S-> ");
    for(z=0;z<c;z++){
        if(stk[z]=='b'){
            printf("%sb",ac);
            stk[z]='S';
            stk[z+1]='\0';
            printf("\n$%s\t%s$\t",stk,a);
    }
}
    for(z=0;z<c-1;z++){
        if(stk[z]=='a' && stk[z+1]=='S'){
            printf("%s2E2",ac);
            stk[z]='S';
            stk[z+1] = '\0';
            printf("\n$%s\t%s$\t",stk,a);
            i=i-1;
    }
}
for(z=0;z<c-1;z++){
        if(stk[z]=='S' && stk[z+1]=='S'){
            printf("%s3E3",ac);
            stk[z]='S';
            stk[z+1]='\0';
            printf("\n$%s\t%s$\t",stk,a);
            i=i-1;
    }
}
return;
}
int main(){
    printf("Grammer is -\n S->SS \n S->aS \n S->b\n");
    strcpy(a,"abb");
    c=strlen(a); 
    strcpy(act,"shift");
    printf("\nstack \t input \taction");
    printf("\n$\t%s$\t",a);
    for(i=0;j<c;i++,j++){
        printf("%s",act);
        stk[i]=a[j];
        stk[i+1]='\0';
        a[j]=' ';
        printf("\n$%s\t%s$\t",stk,a);
        check();
    }
    check();
    if(stk[0]=='S' && stk[1]=='\0'){
        printf("accepted\n");
    }
    else{
        printf("rejected\n");
    }
}


